# Gepetto Viewer to Blender
This add-on allow you to import robot and animation created with Gepetto Viewer. 

### Installation:
1. Go to Edit -> Preferences -> Add-ons -> Install -> locate the add-on archive
2. Tick the box in the add-ons browser
3. In the 3D viewport press the N key to open the side panel, here you will find the Gepetto Viewer menu